# 🚀 Qpixa — Setup Guide

## Step 1: Environment Variables
`.env.example` file ko copy karo aur `.env.local` naam do:

```
NEXT_PUBLIC_SUPABASE_URL=https://yourproject.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
GEMINI_API_KEY=your_gemini_key
HF_TOKEN=your_hf_token  (optional)
```

## Step 2: Install & Run
```bash
npm install
npm run dev
```

## Step 3: Mobile Preview
Same WiFi pe hote hue mobile browser mein kholo:
```
http://YOUR_COMPUTER_IP:3000
```

## Step 4: Deploy to Vercel
1. GitHub pe zip upload karo (GitHub.com → New Repo → Upload Files)
2. Vercel.com pe jaao → Import GitHub repo
3. Environment variables add karo
4. Deploy!

## 🔧 Bugs Fixed in This Version
- ✅ Hardcoded admin passwords removed
- ✅ HuggingFace token env name fixed (HF_TOKEN)
- ✅ toggleLike/toggleSave revert logic fixed
- ✅ fetchPosts infinite loop fix
- ✅ API routes rate limiting added
- ✅ Input validation on all API routes
- ✅ Missing return statement in generate route fixed
