// src/app/api/hf/route.ts
// FIX: Added input validation, model whitelist, and proper null checks

import { NextRequest, NextResponse } from "next/server";

// Whitelisted HuggingFace models — prevents arbitrary model injection
const ALLOWED_HF_MODELS = [
  "stabilityai/stable-diffusion-xl-base-1.0",
  "stabilityai/stable-diffusion-2-1",
  "black-forest-labs/FLUX.1-schnell",
  "black-forest-labs/FLUX.1-dev",
  "runwayml/stable-diffusion-v1-5",
  "prompthero/openjourney-v4",
];

// Simple in-memory rate limiter (per IP, resets on restart)
// For production, use Upstash Redis or Vercel KV
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 20; // requests
const RATE_WINDOW = 60_000; // 1 minute

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW });
    return true;
  }
  if (entry.count >= RATE_LIMIT) return false;
  entry.count++;
  return true;
}

export async function POST(req: NextRequest) {
  // Rate limiting
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(ip)) {
    return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });
  }

  try {
    // FIX: Validate inputs before using them
    const body = await req.json();
    const { modelId, inputs, options } = body;

    if (!modelId || typeof modelId !== 'string') {
      return NextResponse.json({ error: "modelId is required and must be a string." }, { status: 400 });
    }
    if (!inputs || typeof inputs !== 'string') {
      return NextResponse.json({ error: "inputs is required and must be a string." }, { status: 400 });
    }
    // FIX: Whitelist check to prevent arbitrary model injection
    if (!ALLOWED_HF_MODELS.includes(modelId)) {
      return NextResponse.json({ error: "Model not allowed." }, { status: 400 });
    }

    // FIX: Env var name aligned — use HF_TOKEN (server-only, no NEXT_PUBLIC_ prefix)
    const token = process.env.HF_TOKEN;
    if (!token) {
      return NextResponse.json({ error: "HF_TOKEN is not configured on the server." }, { status: 500 });
    }

    const response = await fetch(
      `https://router.huggingface.co/models/${modelId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        method: "POST",
        body: JSON.stringify({
          inputs,
          options: options || { wait_for_model: true },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      return NextResponse.json({ error: errorText || "Hugging Face API error" }, { status: response.status });
    }

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64 = buffer.toString('base64');
    const contentType = response.headers.get('content-type') || 'image/jpeg';

    return NextResponse.json({ imageUrl: `data:${contentType};base64,${base64}` });
  } catch (error: any) {
    console.error("HF Proxy Error:", error);
    return NextResponse.json({ error: error.message || "Internal Server Error" }, { status: 500 });
  }
}
