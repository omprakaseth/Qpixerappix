// src/app/api/generate/route.ts
// FIX: Added missing return statement at end of function (was silently returning undefined)
// FIX: Added input validation

import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";

// Simple rate limiter
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (entry.count >= 30) return false;
  entry.count++;
  return true;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(ip)) {
    return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });
  }

  try {
    const { prompt, model, image, type, config } = await req.json();

    // FIX: Validate required fields
    if (!type || !['text', 'image'].includes(type)) {
      return NextResponse.json({ error: "type must be 'text' or 'image'." }, { status: 400 });
    }
    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: "prompt is required." }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "GEMINI_API_KEY is not configured." }, { status: 500 });
    }

    if (type === 'text') {
      const genAI = new GoogleGenAI({ apiKey });
      const genModel = (genAI as any).getGenerativeModel({ model: model || "gemini-2.0-flash" });
      const result = await genModel.generateContent(prompt);
      const response = await result.response;
      return NextResponse.json({ text: response.text() });
    }

    if (type === 'image') {
      // Imagen 3 via @google/genai SDK — use Pollinations/HF as fallback for now
      return NextResponse.json({
        error: "Imagen 3 is currently under maintenance. Please use Flux.1 or SDXL models.",
        suggestedModels: ["flux", "stabilityai/stable-diffusion-xl-base-1.0"],
      }, { status: 400 });
    }

    // FIX: Missing return — was falling through with no response (500 silence)
    return NextResponse.json({ error: "Unknown request type." }, { status: 400 });

  } catch (error: any) {
    console.error("Gemini Proxy Error:", error);
    return NextResponse.json({ error: error.message || "Internal Server Error" }, { status: 500 });
  }
}
