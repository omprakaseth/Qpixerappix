import { NextRequest, NextResponse } from "next/server";

// Simple rate limiter
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  if (entry.count >= 30) return false;
  entry.count++;
  return true;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(ip)) {
    return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });
  }

  try {
    const { prompt, model, width, height, seed, nologo, enhance } = await req.json();

    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      return NextResponse.json({ error: "prompt is required." }, { status: 400 });
    }

    const queryParams = new URLSearchParams({
      width: width?.toString() || '1024',
      height: height?.toString() || '1024',
      seed: seed?.toString() || Math.floor(Math.random() * 1000000).toString(),
      nologo: nologo ? 'true' : 'false',
      enhance: enhance ? 'true' : 'false',
      model: model || 'flux'
    });

    const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt.trim())}?${queryParams.toString()}`;
    return NextResponse.json({ imageUrl });
  } catch (error: any) {
    console.error("Pollinations Proxy Error:", error);
    return NextResponse.json({ error: error.message || "Internal Server Error" }, { status: 500 });
  }
}
