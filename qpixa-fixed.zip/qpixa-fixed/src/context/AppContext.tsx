"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useRef } from 'react';
import { supabase, isPlaceholder } from '@/integrations/supabase/client';
import type { User, Session } from '@supabase/supabase-js';
import { toast } from 'sonner';
import { analytics } from '@/lib/analytics';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import { Post, Profile, UploadingPost } from '@/types';

interface AppState {
  posts: Post[];
  setPosts: React.Dispatch<React.SetStateAction<Post[]>>;
  initialLoading: boolean;
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  isLoggedIn: boolean;
  isPro: boolean;
  credits: number;
  setCredits: React.Dispatch<React.SetStateAction<number>>;
  uploadingPost: UploadingPost | null;
  startUpload: (data: Omit<UploadingPost, 'id' | 'progress' | 'status'>) => Promise<void>;
  retryUpload: () => Promise<void>;
  clearUpload: () => void;
  toggleLike: (id: string) => void;
  toggleSave: (id: string) => void;
  addPost: (post: Post) => void;
  deletePost: (id: string) => Promise<void>;
  updatePost: (id: string, updates: Partial<Post>) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  fetchPosts: (force?: boolean) => Promise<void>;
  fetchPostById: (id: string) => Promise<Post | null>;
  selectedPost: Post | null;
  setSelectedPost: (post: Post | null) => void;
  viewingCreator: string | null;
  setViewingCreator: (creator: string | null) => void;
  showCreatePost: boolean;
  setShowCreatePost: (show: boolean) => void;
  createPostData: { imageUrl?: string; prompt?: string };
  setCreatePostData: (data: { imageUrl?: string; prompt?: string }) => void;
  showSettings: boolean;
  setShowSettings: (show: boolean) => void;
  showSubscription: boolean;
  setShowSubscription: (show: boolean) => void;
  showAuth: boolean;
  setShowAuth: (show: boolean) => void;
  authMode: 'login' | 'signup';
  setAuthMode: (mode: 'login' | 'signup') => void;
  deferredPrompt: any;
  installApp: () => Promise<void>;
}

export const AppContext = createContext<AppState | null>(null);

import { MOCK_POSTS } from './mock_posts';

export function AppProvider({ children }: { children: ReactNode }) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [credits, setCredits] = useState(40);
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [uploadingPost, setUploadingPost] = useState<UploadingPost | null>(null);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [viewingCreator, setViewingCreator] = useState<string | null>(null);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [createPostData, setCreatePostData] = useState<{ imageUrl?: string; prompt?: string }>({});
  const [showSettings, setShowSettings] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  const { deferredPrompt, promptInstall: installApp } = usePWAInstall();

  const startUpload = async (data: Omit<UploadingPost, 'id' | 'progress' | 'status'>) => {
    const uploadId = `upload-${Date.now()}`;
    const newUpload: UploadingPost = { ...data, id: uploadId, progress: 0, status: 'uploading' };
    setUploadingPost(newUpload);
    performUpload(newUpload);
  };

  const retryUpload = async () => {
    if (!uploadingPost) return;
    const retrying = { ...uploadingPost, status: 'uploading' as const, progress: 0, error: undefined };
    setUploadingPost(retrying);
    performUpload(retrying);
  };

  const clearUpload = () => setUploadingPost(null);

  const performUpload = async (upload: UploadingPost) => {
    if (!user) {
      setUploadingPost(prev => prev ? { ...prev, status: 'error', error: 'User not logged in' } : null);
      return;
    }

    try {
      // Ensure profile exists before posting
      const { data: existingProfile } = await supabase.from('profiles').select('id').eq('id', user.id).single();
      if (!existingProfile) {
        const username = user.user_metadata?.username || user.email?.split('@')[0] || 'user';
        const displayName = user.user_metadata?.display_name || username;
        await supabase.from('profiles').insert({ id: user.id, username, display_name: displayName });
      }

      let finalUrl = upload.previewUrl;

      if (upload.file) {
        setUploadingPost(prev => prev ? { ...prev, progress: 10 } : null);
        const fileExt = upload.file.name.split('.').pop();
        const fileName = `${Date.now()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage.from('prompt-images').upload(filePath, upload.file, {
          contentType: upload.file.type,
          upsert: false,
        });
        if (uploadError) throw uploadError;

        setUploadingPost(prev => prev ? { ...prev, progress: 60 } : null);
        const { data } = supabase.storage.from('prompt-images').getPublicUrl(filePath);
        finalUrl = data.publicUrl;
      } else if (finalUrl && finalUrl.startsWith('data:')) {
        try {
          setUploadingPost(prev => prev ? { ...prev, progress: 30 } : null);
          const res = await fetch(finalUrl);
          const blob = await res.blob();
          const filePath = `${user.id}/ai-${Date.now()}.png`;
          const { error: uploadError } = await supabase.storage.from('prompt-images').upload(filePath, blob, { contentType: 'image/png' });
          if (!uploadError) {
            const { data: { publicUrl } } = supabase.storage.from('prompt-images').getPublicUrl(filePath);
            finalUrl = publicUrl;
          }
        } catch (e) {
          console.error('Error uploading base64 to storage:', e);
        }
      }

      const safeTitle = (typeof upload.title === 'string' ? upload.title : '').trim() || 'Untitled';
      const safePrompt = (typeof upload.prompt === 'string' ? upload.prompt : '').trim() || 'No prompt provided';

      const availableCategories = ['Portrait', 'Anime', 'Cars', 'Fantasy', 'Nature', 'Shorts'];
      const tagsArray = (upload.tags || '').split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
      let detectedCategory = 'Trending';
      for (const cat of availableCategories) {
        if (tagsArray.includes(cat.toLowerCase())) { detectedCategory = cat; break; }
      }

      const extendedData = {
        creator_id: user.id,
        title: safeTitle,
        prompt: safePrompt,
        image_url: finalUrl || '',
        is_short: upload.type === 'short',
        tags: (upload.tags || '').split(',').map(t => t.trim()).filter(Boolean),
        category: detectedCategory,
        is_hidden: false,
      };

      const { data: insertedData, error } = await supabase.from('posts').insert(extendedData).select('*, profiles:creator_id (*)').single();

      if (error) {
        // Fallback to minimal insert
        const { data: retryData, error: retryError } = await supabase.from('posts').insert({
          creator_id: user.id, title: safeTitle, prompt: safePrompt, image_url: finalUrl || '',
        }).select('*, profiles:creator_id (*)').single();
        if (retryError) throw retryError;
        if (retryData) setPosts(prev => [formatPost(retryData), ...prev]);
        toast.info('Post published!');
      } else if (insertedData) {
        setPosts(prev => [formatPost(insertedData), ...prev]);
        analytics.trackPostPublished(upload.id, detectedCategory, upload.type === 'short');
        toast.success(`${upload.type === 'short' ? 'Short' : 'Post'} published!`);
      }

      setUploadingPost(prev => prev ? { ...prev, progress: 100, status: 'success' } : null);
      setTimeout(() => { fetchPosts(true).catch(console.error); }, 1500);
      setTimeout(() => { setUploadingPost(current => current?.id === upload.id ? null : current); }, 3000);

    } catch (err: any) {
      console.error('Upload error:', err);
      setUploadingPost(prev => prev ? { ...prev, status: 'error', error: err.message || 'Upload failed' } : null);
      toast.error(`Upload failed: ${err.message}`);
    }
  };

  const formatPost = useCallback((p: any): Post => ({
    id: p.id,
    title: p.title || 'Untitled',
    imageUrl: p.image_url || '',
    creator: {
      id: p.creator_id,
      name: p.profiles?.display_name || 'Unknown',
      username: p.profiles?.username ? `@${p.profiles.username}` : '@user',
      avatar: p.profiles?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${p.creator_id}`,
      initials: (p.profiles?.display_name || 'U').substring(0, 2).toUpperCase(),
      isVerified: p.profiles?.is_verified || false,
    },
    prompt: p.prompt || '',
    tags: p.tags || [],
    category: p.category || 'General',
    style: p.style || 'Standard',
    aspectRatio: p.aspect_ratio || '1:1',
    views: p.views || 0,
    likes: p.likes || 0,
    saves: p.saves || 0,
    comments: p.comments || 0,
    createdAt: p.created_at,
    isLiked: false,
    isSaved: false,
    isShort: p.is_short || false,
  }), []);

  // FIX: Removed posts.length from dependency array to prevent infinite re-creation
  // FIX: hasFetchedPosts ref is now properly used without posts.length dependency
  const hasFetchedPosts = useRef(false);

  const fetchPosts = useCallback(async (force = false) => {
    if (!force && hasFetchedPosts.current) {
      setInitialLoading(false);
      return;
    }
    hasFetchedPosts.current = true;
    setInitialLoading(true);

    if (isPlaceholder) {
      setPosts(MOCK_POSTS);
      setInitialLoading(false);
      return;
    }

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Request timed out after 10s')), 10000)
    );

    try {
      const fetchPromise = supabase
        .from('posts')
        .select('*, profiles:creator_id (*)')
        .eq('is_hidden', false)
        .order('created_at', { ascending: false })
        .limit(100);

      const response: any = await Promise.race([fetchPromise, timeoutPromise]);
      const { data, error } = response;

      if (error) {
        // Fallback to simple fetch without join
        const { data: simpleData, error: simpleError } = await supabase
          .from('posts').select('*').eq('is_hidden', false)
          .order('created_at', { ascending: false }).limit(100);
        if (simpleError) throw simpleError;
        const formatted = (simpleData || []).map(formatPost);
        // Always append mock posts for a full feed experience
        setPosts([...formatted, ...MOCK_POSTS]);
      } else {
        const formatted = (data || []).map(formatPost);
        setPosts([...formatted, ...MOCK_POSTS]);
      }
    } catch (err) {
      console.error('fetchPosts error:', err);
      setPosts(MOCK_POSTS);
    } finally {
      setInitialLoading(false);
    }
  // FIX: Only formatPost and isPlaceholder needed — removed posts.length
  }, [formatPost, isPlaceholder]);

  const fetchPostById = async (id: string): Promise<Post | null> => {
    if (isPlaceholder) return MOCK_POSTS.find(p => p.id === id) || null;
    try {
      const { data, error } = await supabase.from('posts').select('*, profiles:creator_id (*)').eq('id', id).single();
      if (error) throw error;
      return data ? formatPost(data) : null;
    } catch (err) {
      console.error('Error fetching post by id:', err);
      return null;
    }
  };

  const fetchProfile = useCallback(async (currentUser: User) => {
    let { data, error } = await supabase.from('profiles').select('*').eq('id', currentUser.id).single();

    if (error?.code === 'PGRST116') {
      const username = currentUser?.user_metadata?.username || currentUser?.email?.split('@')[0] || 'user';
      const displayName = currentUser?.user_metadata?.display_name || username;
      const { data: newProfile } = await supabase.from('profiles')
        .insert({ id: currentUser.id, username, display_name: displayName }).select().single();
      data = newProfile;
    }

    if (data) {
      // FIX: Use DB role check instead of hardcoded email for admin detection
      const isAdminEmail = process.env.NEXT_PUBLIC_ADMIN_EMAILS?.split(',').includes(currentUser.email || '');
      if (isAdminEmail && (data as any).role !== 'admin') {
        const { data: updatedProfile } = await supabase.from('profiles')
          .update({ role: 'admin' } as any).eq('id', currentUser.id).select().single();
        if (updatedProfile) data = updatedProfile;
      }
      setProfile(data as Profile);
      // FIX: Credits from DB, not hardcoded email check
      setCredits((data as any).credits ?? 40);
    }
  }, []);

  useEffect(() => {
    fetchPosts().catch(console.error);
    if (isPlaceholder) return;

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        if (_event === 'SIGNED_IN') {
          analytics.trackUserGrowth(sess.user.id, sess.user.email, sess.user.app_metadata.provider || 'email');
        } else {
          analytics.identify(sess.user.id, { $email: sess.user.email });
        }
        fetchProfile(sess.user);
      } else {
        setProfile(null);
        setCredits(40);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchPosts, fetchProfile]);

  // FIX: toggleLike — store original state before optimistic update for correct revert
  const toggleLike = async (id: string) => {
    if (!user || isPlaceholder) return;
    const post = posts.find(p => p.id === id);
    if (!post) return;

    // Snapshot original values BEFORE optimistic update
    const originalLiked = post.isLiked;
    const originalLikes = post.likes;

    // Optimistic update
    setPosts(prev => prev.map(p =>
      p.id === id ? { ...p, isLiked: !originalLiked, likes: originalLiked ? originalLikes - 1 : originalLikes + 1 } : p
    ));

    if (post.isMock) return;

    try {
      if (originalLiked) {
        await supabase.from('post_likes').delete().match({ post_id: id, user_id: user.id });
      } else {
        await supabase.from('post_likes').insert({ post_id: id, user_id: user.id });
        if (post.creator.id !== user.id && post.creator.id !== 'system') {
          await (supabase as any).from('user_notifications').insert({
            user_id: post.creator.id, actor_id: user.id, type: 'like',
            title: 'New Like! ❤️',
            message: `${profile?.display_name || 'Someone'} liked your post "${post.title}"`,
            link: `/post/${post.id}`,
          });
        }
      }
    } catch (err) {
      console.error('Error toggling like:', err);
      toast.error('Failed to update like status');
      // FIX: Revert to original values (not double-flipped)
      setPosts(prev => prev.map(p =>
        p.id === id ? { ...p, isLiked: originalLiked, likes: originalLikes } : p
      ));
    }
  };

  // FIX: toggleSave — same fix as toggleLike
  const toggleSave = async (id: string) => {
    if (!user || isPlaceholder) return;
    const post = posts.find(p => p.id === id);
    if (!post) return;

    const originalSaved = post.isSaved;
    const originalSaves = post.saves;

    setPosts(prev => prev.map(p =>
      p.id === id ? { ...p, isSaved: !originalSaved, saves: originalSaved ? originalSaves - 1 : originalSaves + 1 } : p
    ));

    if (post.isMock) return;

    try {
      if (originalSaved) {
        await supabase.from('favorites').delete().match({ image_url: post.imageUrl, user_id: user.id });
      } else {
        await supabase.from('favorites').insert({ image_url: post.imageUrl, prompt: post.prompt, user_id: user.id });
      }
    } catch (err) {
      console.error('Error toggling save:', err);
      toast.error('Failed to update save status');
      // FIX: Revert to original values
      setPosts(prev => prev.map(p =>
        p.id === id ? { ...p, isSaved: originalSaved, saves: originalSaves } : p
      ));
    }
  };

  const addPost = (post: Post) => setPosts(prev => [post, ...prev]);

  const deletePost = async (id: string) => {
    if (!user) return;
    if (id.startsWith('mock-')) {
      setPosts(prev => prev.filter(p => p.id !== id));
      toast.success('Sample post removed');
      return;
    }
    try {
      const { error } = await supabase.from('posts').delete().eq('id', id).eq('creator_id', user.id);
      if (error) throw error;
      setPosts(prev => prev.filter(p => p.id !== id));
      toast.success('Post deleted successfully');
    } catch (err) {
      console.error('Error deleting post:', err);
      toast.error('Failed to delete post');
    }
  };

  const updatePost = async (id: string, updates: Partial<Post>) => {
    if (!user) return;
    if (id.startsWith('mock-')) {
      setPosts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      return;
    }
    try {
      const { error } = await supabase.from('posts')
        .update({ title: updates.title, prompt: updates.prompt, tags: updates.tags })
        .eq('id', id).eq('creator_id', user.id);
      if (error) throw error;
      setPosts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      toast.success('Post updated');
    } catch (err) {
      console.error('Error updating post:', err);
      toast.error('Failed to update post');
    }
  };

  const signOut = async () => {
    if (isPlaceholder) {
      setUser(null); setSession(null); setProfile(null);
      analytics.reset();
      return;
    }
    await supabase.auth.signOut();
    analytics.reset();
    setUser(null); setSession(null); setProfile(null);
  };

  const refreshProfile = async () => {
    if (user) await fetchProfile(user);
  };

  const isLoggedIn = !!user;
  const isPro = profile?.subscription_plan === 'pro';

  return (
    <AppContext.Provider value={{
      posts, setPosts, initialLoading, user, session, profile, isLoggedIn, isPro, credits, setCredits,
      uploadingPost, startUpload, retryUpload, clearUpload,
      toggleLike, toggleSave, addPost, deletePost, updatePost, signOut, refreshProfile, fetchPosts, fetchPostById,
      selectedPost, setSelectedPost, viewingCreator, setViewingCreator,
      showCreatePost, setShowCreatePost, createPostData, setCreatePostData,
      showSettings, setShowSettings, showSubscription, setShowSubscription,
      showAuth, setShowAuth, authMode, setAuthMode,
      deferredPrompt, installApp,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppState() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppState must be used within AppProvider');
  return ctx;
}
